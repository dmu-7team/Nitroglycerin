using System;

namespace Xsolla.Auth
{
	[Serializable]
	public class LoginLink
	{
		// Link for authentication.
		public string login_url;
	}
}