using System;

namespace Xsolla.Auth
{
	[Serializable]
	public class OperationId
	{
		// Operation ID.
		public string operation_id;
	}
}