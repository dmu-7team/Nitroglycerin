using System;

namespace Xsolla.Auth
{
	[Serializable]
	internal class AccessTokenResponse
	{
		public string token;
	}
}