using System;

namespace Xsolla.Auth
{
	[Serializable]
	internal class ResendConfirmationLinkRequest
	{
		public string username;
	}
}