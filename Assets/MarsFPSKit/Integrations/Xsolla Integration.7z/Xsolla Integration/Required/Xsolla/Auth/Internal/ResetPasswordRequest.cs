using System;

namespace Xsolla.Auth
{
	[Serializable]
	internal class ResetPasswordRequest
	{
		public string username;
	}
}