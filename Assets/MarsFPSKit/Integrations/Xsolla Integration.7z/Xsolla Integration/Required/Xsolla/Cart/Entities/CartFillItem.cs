using System;

namespace Xsolla.Cart
{
	[Serializable]
	public class CartFillItem
	{
		public string sku;
		public int quantity;
	}
}