﻿using System;

namespace Xsolla.Cart
{
	[Serializable]
	internal class QuantityRequest
	{
		public int quantity;
	}
}