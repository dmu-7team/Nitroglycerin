using System;

namespace Xsolla.Cart
{
	[Serializable]
	internal class RemovePromocodeFromCartRequest
	{
		public string id;
	}
}