using System;
using Xsolla.Core;

namespace Xsolla.Catalog
{
	[Serializable]
	public class StoreItems
	{
		public StoreItem[] items;
	}
}