using System;

namespace Xsolla.Catalog
{
	[Serializable]
	internal class CouponCodeRequest
	{
		public string coupon_code;
	}
}