namespace Xsolla.Core
{
	public class BrowserCloseInfo
	{
		// Whether the browser is closed manually by a user.
		public bool isManually;
	}
}
