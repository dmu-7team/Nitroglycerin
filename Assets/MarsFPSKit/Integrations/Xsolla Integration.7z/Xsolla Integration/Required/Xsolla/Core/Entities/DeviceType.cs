namespace Xsolla.Core
{
	public enum DeviceType
	{
		Android,
		iOS
	}
}