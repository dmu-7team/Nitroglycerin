using System;

namespace Xsolla.Core
{
	[Serializable]
	public class MediaListItem
	{
		public string type;
		public string url;
	}
}