﻿using System;

namespace Xsolla.Core
{
	[Serializable]
	public class OrderData
	{
		public string token;
		public int order_id;
	}
}