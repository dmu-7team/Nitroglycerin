using System;

namespace Xsolla.Core
{
	[Serializable]
	public class OrderId
	{
		public int order_id;
	}
}