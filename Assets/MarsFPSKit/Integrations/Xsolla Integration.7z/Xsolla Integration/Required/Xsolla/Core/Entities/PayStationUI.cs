using System;

namespace Xsolla.Core
{
	[Serializable]
	public class PayStationUI
	{
		public string size;
		public string theme;
		public string version;
		public bool is_independent_windows;
	}
}