using System;

namespace Xsolla.Core
{
	[Serializable]
	public class StoreItemGroup
	{
		public string external_id;
		public string name;
	}
}