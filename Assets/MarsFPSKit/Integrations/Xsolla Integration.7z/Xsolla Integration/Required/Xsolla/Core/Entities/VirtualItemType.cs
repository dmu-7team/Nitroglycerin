namespace Xsolla.Core
{
	public enum VirtualItemType
	{
		None,
		Consumable,
		NonConsumable,
		NonRenewingSubscription,
		VirtualCurrency
	}
}