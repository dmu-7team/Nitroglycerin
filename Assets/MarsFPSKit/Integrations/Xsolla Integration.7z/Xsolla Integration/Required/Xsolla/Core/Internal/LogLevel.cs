namespace Xsolla.Core
{
	public enum LogLevel
	{
		InfoWarningsErrors = 0,
		WarningsErrors = 1,
		Errors = 2
	}
}