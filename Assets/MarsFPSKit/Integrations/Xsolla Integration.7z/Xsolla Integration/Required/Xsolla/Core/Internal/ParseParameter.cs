namespace Xsolla.Core
{
	public enum ParseParameter
	{
		token,
		code,
		challenge_id,
		error_code,
		error_description
	}
}