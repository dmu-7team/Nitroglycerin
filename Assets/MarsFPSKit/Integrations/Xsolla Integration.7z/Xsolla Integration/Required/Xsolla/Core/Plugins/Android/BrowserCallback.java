package com.xsolla.android.payments.callback;

public interface BrowserCallback  {
    void onBrowserClosed(boolean isManually);
}