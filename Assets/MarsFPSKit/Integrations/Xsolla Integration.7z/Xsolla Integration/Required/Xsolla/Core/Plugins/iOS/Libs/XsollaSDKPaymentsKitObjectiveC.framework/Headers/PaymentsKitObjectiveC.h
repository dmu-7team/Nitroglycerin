// XSOLLA_SDK_LICENCE_HEADER_PLACEHOLDER

#import <Foundation/Foundation.h>

//! Project version number for PaymentsKitObjectiveC.
FOUNDATION_EXPORT double PaymentsKitObjectiveCVersionNumber;

//! Project version string for PaymentsKitObjectiveC.
FOUNDATION_EXPORT const unsigned char PaymentsKitObjectiveCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentsKitObjectiveC/PublicHeader.h>


