#ifndef XsollaSDKLoginKitObjectiveC_Bridging_Header_h
#define XsollaSDKLoginKitObjectiveC_Bridging_Header_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#endif /* XsollaSDKLoginKitObjectiveC_Bridging_Header_h */
