#ifndef XsollaSDKPaymentsKitObjectiveC_Bridging_Header_h
#define XsollaSDKPaymentsKitObjectiveC_Bridging_Header_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#endif /* XsollaSDKPaymentsKitObjectiveC_Bridging_Header_h */
