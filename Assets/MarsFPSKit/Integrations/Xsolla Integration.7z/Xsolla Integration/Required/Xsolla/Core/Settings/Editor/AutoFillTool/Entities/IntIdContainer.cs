﻿using System;

namespace Xsolla.Core.Editor.AutoFillSettings
{
	[Serializable]
	public class IntIdContainer
	{
		public int id;
		public string name;
	}
}