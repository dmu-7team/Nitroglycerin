﻿namespace Xsolla.Core.Editor.AutoFillSettings
{
	public enum SettingsType
	{
		MerchantID,
		ProjectID,
		LoginID,
		OAuthID,
		RedirectUrl
	}
}