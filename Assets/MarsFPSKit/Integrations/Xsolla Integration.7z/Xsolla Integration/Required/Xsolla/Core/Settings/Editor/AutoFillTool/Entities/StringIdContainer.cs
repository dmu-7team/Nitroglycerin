﻿using System;

namespace Xsolla.Core.Editor.AutoFillSettings
{
	[Serializable]
	public class StringIdContainer
	{
		public string id;
		public string name;
	}
}