﻿namespace Xsolla.Core.Editor.AutoFillSettings
{
	public enum ToolStep
	{
		Undefined, Auth, Code, Settings, Wait
	}
}