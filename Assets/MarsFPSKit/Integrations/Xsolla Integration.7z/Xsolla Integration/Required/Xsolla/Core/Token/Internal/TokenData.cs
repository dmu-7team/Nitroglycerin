namespace Xsolla.Core
{
	internal class TokenData
	{
		public string accessToken;
		public string refreshToken;
	}
}