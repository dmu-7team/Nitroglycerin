namespace Xsolla.Core
{
	public enum SdkType
	{
		Login,
		Store,
		Subscriptions,
		SettingsFillTool
	}
}