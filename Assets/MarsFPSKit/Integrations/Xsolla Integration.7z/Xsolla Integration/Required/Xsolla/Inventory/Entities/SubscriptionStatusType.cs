namespace Xsolla.Inventory
{
	public enum SubscriptionStatusType
	{
		None,
		Active,
		Expired
	}
}