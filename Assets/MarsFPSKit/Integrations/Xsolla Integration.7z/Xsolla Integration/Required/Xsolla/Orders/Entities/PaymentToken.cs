using System;

namespace Xsolla.Orders
{
	[Serializable]
	public class PaymentToken
	{
		public string token;
	}
}