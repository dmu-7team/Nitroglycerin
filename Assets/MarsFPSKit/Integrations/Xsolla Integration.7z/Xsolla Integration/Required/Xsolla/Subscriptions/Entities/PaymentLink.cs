﻿using System;

namespace Xsolla.Subscriptions
{
	[Serializable]
	public class PaymentLink
	{
		public string link_to_ps;
	}
}