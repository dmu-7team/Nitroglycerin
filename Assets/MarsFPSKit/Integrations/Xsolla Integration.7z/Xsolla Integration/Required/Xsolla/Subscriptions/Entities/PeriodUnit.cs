﻿namespace Xsolla.Subscriptions
{
	public enum PeriodUnit
	{
		Unknown,
		Day,
		Month,
		LifeTime
	}
}