﻿namespace Xsolla.Subscriptions
{
	public enum PlanType
	{
		Unknown,
		All
	}
}