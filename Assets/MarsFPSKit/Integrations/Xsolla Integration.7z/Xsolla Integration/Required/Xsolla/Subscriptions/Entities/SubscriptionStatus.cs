﻿namespace Xsolla.Subscriptions
{
	public enum SubscriptionStatus
	{
		Unknown,
		New,
		Active,
		Canceled,
		NonRenewing,
		Pause
	}
}