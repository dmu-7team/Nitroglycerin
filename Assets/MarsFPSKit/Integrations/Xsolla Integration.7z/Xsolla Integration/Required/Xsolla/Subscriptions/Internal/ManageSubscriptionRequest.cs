﻿using System;

namespace Xsolla.Subscriptions
{
	[Serializable]
	internal class ManageSubscriptionRequest
	{
		public PaymentSettings settings;
	}
}