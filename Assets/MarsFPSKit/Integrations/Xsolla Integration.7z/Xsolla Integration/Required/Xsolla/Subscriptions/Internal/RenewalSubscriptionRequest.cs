﻿using System;

namespace Xsolla.Subscriptions
{
	[Serializable]
	internal class RenewalSubscriptionRequest
	{
		public PaymentSettings settings;
	}
}