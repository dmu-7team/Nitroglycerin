using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class AddUsernameAndEmailResult
	{
		public bool email_confirmation_required;
	}
}