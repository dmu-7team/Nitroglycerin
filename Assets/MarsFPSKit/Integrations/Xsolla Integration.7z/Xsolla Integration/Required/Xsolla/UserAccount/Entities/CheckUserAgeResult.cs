﻿using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class CheckUserAgeResult
	{
		public bool accepted;
	}
}