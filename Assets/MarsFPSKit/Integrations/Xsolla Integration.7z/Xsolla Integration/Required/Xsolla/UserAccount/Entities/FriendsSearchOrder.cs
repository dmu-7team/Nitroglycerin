namespace Xsolla.UserAccount
{
	/// <summary>
	/// Condition for sorting users
	/// </summary>
	public enum FriendsSearchOrder
	{
		Asc,
		Desc
	}
}