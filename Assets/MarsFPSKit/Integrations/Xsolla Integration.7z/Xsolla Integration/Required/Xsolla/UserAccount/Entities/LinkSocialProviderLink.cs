using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class LinkSocialProviderLink
	{
		public string url;
	}
}