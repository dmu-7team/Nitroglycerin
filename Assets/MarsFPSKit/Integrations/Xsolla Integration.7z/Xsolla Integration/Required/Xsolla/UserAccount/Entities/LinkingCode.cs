using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class LinkingCode
	{
		public string code;
	}
}