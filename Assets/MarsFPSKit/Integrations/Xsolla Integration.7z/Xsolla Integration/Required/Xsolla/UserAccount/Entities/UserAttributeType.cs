﻿namespace Xsolla.UserAccount
{
	public enum UserAttributeType
	{
		CUSTOM,
		READONLY
	}
}