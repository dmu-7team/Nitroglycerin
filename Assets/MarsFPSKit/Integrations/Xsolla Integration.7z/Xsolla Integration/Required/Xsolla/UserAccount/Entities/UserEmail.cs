using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class UserEmail
	{
		public string current_email;
	}
}