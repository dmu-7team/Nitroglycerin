using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	public class LinkDeviceRequest
	{
		public string device;
		public string device_id;
	}
}