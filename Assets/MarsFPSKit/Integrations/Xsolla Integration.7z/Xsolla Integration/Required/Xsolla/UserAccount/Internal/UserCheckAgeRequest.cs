﻿using System;

namespace Xsolla.UserAccount
{
	[Serializable]
	internal class UserCheckAgeRequest
	{
		public string dob;
		public string project_id;
	}
}