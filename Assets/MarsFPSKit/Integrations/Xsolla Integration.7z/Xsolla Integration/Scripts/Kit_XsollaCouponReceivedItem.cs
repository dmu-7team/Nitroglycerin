﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Xsolla.Core;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaCouponReceivedItem : MonoBehaviour
        {
            /// <summary>
            /// Image for this item
            /// </summary>
            public Image previewImage;
            /// <summary>
            /// Title for this item
            /// </summary>
            public TextMeshProUGUI title;
            /// <summary>
            /// Description for this item
            /// </summary>
            public TextMeshProUGUI description;
            /// <summary>
            /// XSolla image url
            /// </summary>
            public string imageUrl;

            private void Start()
            {
                if (!string.IsNullOrEmpty(imageUrl))
                   ImageLoader.LoadSprite(imageUrl, (sprite) =>
                    {
                        if (previewImage)
                            previewImage.sprite = sprite;
                    });
                else
                    Debug.LogError("Coupon received item has no image url.");
            }
        }
    }
}