﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Xsolla.Core;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaSingleton : MonoBehaviour
        {
            private static Kit_XsollaSingleton singleton;

            private void Awake()
            {
                if (singleton)
                {
                    Destroy(gameObject);
                }
                else
                {
                    singleton = this;
                    DontDestroyOnLoad(gameObject);

                    WebRequestHelper.Instance.SetReferralAnalytics("mmfpse-xsolla-weapon-store", Kit_XsollaSettings.version);
                }
            }
        }
    }
}